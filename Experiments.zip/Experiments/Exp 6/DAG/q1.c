#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 100

// Structure to represent a node in the DAG
typedef struct Node {
    char value[MAX_LINE_LENGTH];
    struct Node* left;
    struct Node* right;
    struct Node* next; // For chaining nodes with the same value
} Node;

// Function to create a new node
Node* createNode(char* value) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    strcpy(newNode->value, value);
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->next = NULL;
    return newNode;
}

// Function to search for a node with the given value in the DAG
Node* searchNode(Node* root, char* value) {
    while (root != NULL) {
        if (strcmp(root->value, value) == 0)
            return root;
        root = root->next;
    }
    return NULL;
}

// Function to add a new node or return an existing node with the given value
Node* addNode(Node** root, char* value) {
    Node* newNode = createNode(value);
    Node* existingNode = searchNode(*root, value);
    if (existingNode != NULL) {
        free(newNode); // Free the newly created node
        return existingNode;
    }
    newNode->next = *root;
    *root = newNode;
    return newNode;
}

// Function to print the DAG
void printDAG(Node* root) {
    printf("DAG:\n");
    while (root != NULL) {
        printf("Value: %s, Left: %s, Right: %s\n", root->value,
               (root->left != NULL) ? root->left->value : "NULL",
               (root->right != NULL) ? root->right->value : "NULL");
        root = root->next;
    }
}

int main() {
    FILE* file = fopen("code.txt", "r");
    if (file == NULL) {
        perror("Error opening the file");
        return 1;
    }

    Node* root = NULL;
    char line[MAX_LINE_LENGTH];

    while (fgets(line, MAX_LINE_LENGTH, file) != NULL) {
        printf("Read line: %s\n", line); // Debugging statement
        
        char arg1[MAX_LINE_LENGTH], arg2[MAX_LINE_LENGTH], result[MAX_LINE_LENGTH];
        sscanf(line, "%s = %s %s", result, arg1, arg2);
        printf("Parsed values: result=%s, arg1=%s, arg2=%s\n", result, arg1, arg2); // Debugging statement
        
        Node* leftNode = addNode(&root, arg1);
        Node* rightNode = addNode(&root, arg2);
        Node* resultNode = addNode(&root, result);

        // Attach left and right nodes to the result node
        resultNode->left = leftNode;
        resultNode->right = rightNode;
    }

    fclose(file);

    printDAG(root);

    // Free allocated memory
    while (root != NULL) {
        Node* temp = root;
        root = root->next;
        free(temp);
    }

    return 0;
}

