#include<stdio.h>
#include<ctype.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

void main()
{
 int index = 0, expressionIndex = 0, memoryIndex = 0, expressionLength;
 void *memoryAddress, *memoryTable[5];
 char character, searchCharacter, expression[15], dataType;

 printf("Expression terminated by $:");

 // Read the expression character by character until '$' is encountered
 while((character=getchar())!='$')
 {
  expression[index]=character;
  index++;
 }
 expressionLength=index-1;

 printf("Given Expression:");
 index=0;

 // Print the given expression
 while(index<=expressionLength)
 {
  printf("%c",expression[index]);
  index++;
 }
 printf("\nSymbol Table\n");
 printf("Symbol \t addr \t\t type");

 // Process each character in the expression
 while(expressionIndex<=expressionLength)
 {
  character=expression[expressionIndex];

  // Check if the character is an alphabet (identifier)
  if(isalpha(toascii(character)))
  {
   // Allocate memory for the identifier and store the memory address in the symbol table
   memoryAddress=malloc(character);
   memoryTable[memoryIndex]=memoryAddress;
   dataType=character;
   printf("\n%c \t %d \t identifier\n",character,memoryAddress);
   memoryIndex++;
   expressionIndex++;
  }
  else
  {
   searchCharacter=character;

   // Check if the character is an operator (+, -, *, or =)
   if(searchCharacter=='+'||searchCharacter=='-'||searchCharacter=='*'||searchCharacter=='=')
   {
    // Allocate memory for the operator and store the memory address in the symbol table
    memoryAddress=malloc(searchCharacter);
    memoryTable[memoryIndex]=memoryAddress;
    dataType=searchCharacter;
    printf("\n %c \t %d \t operator\n",searchCharacter,memoryAddress);
    memoryIndex++;
    expressionIndex++;
   }
  }
}
}

