#include <stdio.h>
#include <ctype.h>
#include <string.h>

// Different token types
enum tokens { NONE = 0, OPERATOR, RIGHT_PARENTHESES, LEFT_PARENTHESES, CONSTANT, IDENTIFIER, KEYWORD, END };

// Token types for printing
const char *token_table[8] = {"NONE", "OPERATOR", "RIGHT PARENTHESES", "LEFT PARENTHESES", "CONSTANT", "IDENTIFIER", "KEYWORD", "END"};

// Function to check if a given string is a keyword
int is_keyword(const char *str) {
    const char *keywords[] = {"int", "float", "double", "char", "if", "else", "return", "printf"};
    int num_keywords = sizeof(keywords) / sizeof(keywords[0]);

    // Loop through the keyword array and compare each element with the given string
    for (int i = 0; i < num_keywords; ++i) {
        if (strcmp(str, keywords[i]) == 0) {
            return 1; // Return 1 if the string is a keyword
        }
    }

    return 0; // Return 0 if the string is not a keyword
}

// Function to tokenize the input
int lexer() {
    int c;
    int state = 0;
    char buffer[100];
    int buffer_index = 0;

    while ((c = getchar()) != EOF) {
        switch (state) {
            case 0: // Initial state
                switch (c) {
                    case '+': case '-': case '*': case '/': case '=': case ';': state = 1; break; // Operators
                    case '(': state = 2; break; // Right parentheses
                    case ')': state = 3; break; // Left parentheses
                    case ' ': case '\t': case '\n': state = 0; break; // Ignore white space
                    default:
                        if (isdigit(c)) {
                            state = 4; break; // Constant
                        } else if (isalpha(c)) {
                            buffer[buffer_index++] = c;
                            state = 5; break; // Identifier or keyword
                        } else {
                            printf("Error at %c\n", c);
                            state = 6; // Error state
                        }
                        break;
                }
                break;

            case 1: return OPERATOR; break; // Return operator token
            case 2: return RIGHT_PARENTHESES; break; // Return right parentheses token
            case 3: return LEFT_PARENTHESES; break; // Return left parentheses token
            case 4: // Constant state
                printf("%c",c);
                if (isdigit(c)) {
                    state = 4; // Continue reading digits
                } else {
                    state = 6; // Error state
                    ungetc(c, stdin); // Put non-digit character back into input stream
                    buffer[buffer_index] = '\0'; // Null-terminate the buffer
                    return CONSTANT; // Return constant token
                }
                break;

            case 5: // Identifier or keyword state
                if (isalnum(c)) {
                    buffer[buffer_index++] = c;
                    state = 5; // Continue reading alphanumeric characters
                } else {
                    state = 6; // Error state
                    ungetc(c, stdin); // Put non-alphanumeric character back into input stream
                    buffer[buffer_index] = '\0'; // Null-terminate the buffer
                    return is_keyword(buffer) ? KEYWORD : IDENTIFIER; // Return keyword token if the buffer is a keyword, otherwise return identifier token
                }
                break;

            case 6: break; // Error state
        }
    }
    return END; // Return end token when reaching the end of input
}

int main() {
    int token;
    while ((token = lexer()) != END) {
        printf("Token: %s\n", token_table[token]);
    }
    return 0;
}

