#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main() {
    int numStates, numInputs, numFinalStates;
    
    // Get the total number of states from the user
    printf("Enter the total number of states: ");
    scanf("%d", &numStates);
    
    // Create an array to store the states
    char states[numStates];
    
    // Get the states from the user
    printf("Enter the states: \n");
    for (int i = 0; i < numStates; i++) {
        while (getchar() != '\n')
            continue;
        scanf("%c", &states[i]);
    }
    
    // Get the total number of input symbols from the user
    printf("Enter the total number of input symbols: ");
    scanf("%d", &numInputs);
    
    // Create an array to store the input symbols
    char inputs[numInputs];
    
    // Get the input symbols from the user
    printf("Enter the input symbols: \n");
    for (int i = 0; i < numInputs; i++) {
        while (getchar() != '\n')
            continue;
        scanf("%c", &inputs[i]);
    }
    
    // Get the total number of final states from the user
    printf("Enter the total number of final states: ");
    scanf("%d", &numFinalStates);
    
    // Create an array to store the final states
    char finalStates[numFinalStates];
    
    // Get the final states from the user
    printf("Enter the final states: \n");
    for (int i = 0; i < numFinalStates; i++) {
        while (getchar() != '\n')
            continue;
        scanf("%c", &finalStates[i]);
    }
    
    // Create a 2D array to represent the DFA
    char dfa[numStates + 1][numInputs + 1];
    
    // Initialize the first row with the input symbols
    for (int i = 1; i <= numInputs; i++) {
        dfa[0][i] = inputs[i - 1];
    }
    
    // Initialize the first column with the states
    for (int i = 1; i <= numStates; i++) {
        dfa[i][0] = states[i - 1];
    }
    
    // Get the transitions for each state and input symbol
    for (int i = 1; i <= numStates; i++) {
        for (int j = 1; j <= numInputs; j++) {
            printf("Enter the transition of state %c for input %c:\n", dfa[i][0], dfa[0][j]);
            while (getchar() != '\n')
                continue;
            scanf("%c", &dfa[i][j]);
        }
    }
    
    // Print the DFA table
    for (int i = 0; i <= numStates; i++) {
        for (int j = 0; j <= numInputs; j++) {
            printf("\t%c", dfa[i][j]);
        }
        printf("\n");
    }
    
    // Get the string from the user
    printf("Enter the string: ");
    char str[10];
    scanf("%s", str);
    int length = strlen(str);
    char currentState = dfa[1][0];
    int rowIndex, colIndex;
    
    // Process each character in the string
    for (int i = 0; i < length; i++) {
        printf("(%c,%c)->", currentState, str[i]);
        
        // Find the column index for the current input symbol
        for (colIndex = 1; colIndex <= numInputs; colIndex++) {
            if (dfa[0][colIndex] == str[i]) {
                break;
            }
        }
        
        // Find the row index for the current state
        for (rowIndex = 1; rowIndex <= numStates; rowIndex++) {
            if (currentState == dfa[rowIndex][0]) {
                break;
            }
        }
        
        // Update the current state based on the transition
        for (int l = 1; l <= numStates; l++) {
            if (dfa[l][0] == dfa[rowIndex][colIndex]) {
                currentState = dfa[l][0];
                break;
            }
        }
    }
    
    bool isAccepted = false;
    
    // Check if the final state is one of the accepted states
    for (int i = 0; i < numFinalStates; i++) {
        if (currentState == finalStates[i]) {
            printf("%c\nString accepted\n", currentState);
            isAccepted = true;
            break;
        }
    }
    
    // Print the result if the string is not accepted
    if (!isAccepted) {
        printf("%c\nString not accepted\n", currentState);
    }
    
    return 0;
}

